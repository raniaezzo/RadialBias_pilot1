function plotpolar(numCond, paramsetting, figuresdir, main_conditions, ...
    mapdegree, ci_values)
    
    conf_interval = 95;

    if numCond == 4
        colors = ['c','b','r','m'];
        condNames = {'radialout', 'radialin','tangleft','tangright'};
    elseif numCond == 2
        colors = ['b','r'];
        condNames = {'radial','tangential'};
    end
    
    if conf_interval == 95
        select_idx = 1;
    elseif conf_interval == 68
        select_idx = 2;
    end
    
    % extract subjectname
    parts = strsplit(figuresdir, '/'); subjname = parts{end-1};
    possibleLocs = 8;
    addedconst= 1.5; % added const to min
    %main_conditions = {params_radialout,params_radialin,params_tangleft,params_tangright};
    %ci_values = {bootci_radialout,bootci_radialin,bootci_tangleft,bootci_tangright};
    
    if strcmp(paramsetting, 'bias')
        paramidx = 1;
        % calculate min (bias value - 95% error) across all conditions - const across
        % plot a circle on polar plot
        minlist_bias = [];
        for i=1:length(main_conditions)
            for fn = fieldnames(main_conditions{i})'
                % (1,1,select_index) refers to (lowerbound, biasparam, 95ci)
                biaswerror = main_conditions{i}.(fn{1})(:,1)+ ci_values{i}.(fn{1})(1,1,select_idx);
                minlimit_bias = min(biaswerror);
                minlist_bias = [minlist_bias minlimit_bias];
            end
        end
        set_min = abs(min(minlist_bias)-addedconst);
    elseif strcmp(paramsetting, 'sensitivity')
        paramidx = 2;
        set_min = 0;
    end
    
    figure
    Axis = gca; % current axes
    
    possiblethetas_deg = linspace(0,315,8);
    for i=1:length(main_conditions) % conditions   
        theta = []; rho = []; ci_95_lb = []; ci_68_lb = []; ci_95_ub = []; ci_68_ub = [];
        for fn = fieldnames(main_conditions{i})' % locations
            %disp(fn{1})
            theta = [theta deg2rad(mapdegree(fn{1}))];
            rho = [rho main_conditions{i}.(fn{1})(paramidx)];
            ci_95_lb = [ci_95_lb ci_values{i}.(fn{1})(1, paramidx, select_idx)];
            ci_95_ub = [ci_95_ub ci_values{i}.(fn{1})(2, paramidx, select_idx)];
            ci_68_lb = [ci_68_lb ci_values{i}.(fn{1})(1, paramidx, select_idx)];
            ci_68_ub = [ci_68_ub ci_values{i}.(fn{1})(2, paramidx, select_idx)];
        end
        rho = rho+set_min; % will be +0 for sensitivity
        
        [theta,idx] = sort(theta); % order theta from least to greatest
        rho = rho(idx); ci_95_lb = ci_95_lb(idx); ci_68_lb = ci_68_lb(idx);
        ci_95_ub = ci_95_ub(idx); ci_68_ub = ci_68_ub(idx);
       
        % insert empty [] for data not yet collected -- clean this up later
        possiblethetas_rad = deg2rad(possiblethetas_deg);
        emtyidx = ismember(num2str(possiblethetas_rad'), num2str(theta'), 'rows')';
        emtyidx = double(emtyidx); emtyidx(~emtyidx)=nan;
        %newtheta = emtyidx.*possiblethetas_rad; theta = newtheta; 
        % actually, I can just do this:
        theta = possiblethetas_rad;
        cnt = 1; new_rho = emtyidx; new_ci_95_lb = emtyidx; new_ci_68_lb = emtyidx;
        new_ci_95_ub = emtyidx; new_ci_68_ub = emtyidx;
        for pp=1:length(emtyidx)
            if isnan(emtyidx(pp))
                continue
            else
               new_rho(pp) = rho(cnt); new_ci_95_lb(pp) = ci_95_lb(cnt);
               new_ci_68_lb(pp) = ci_68_ub(cnt); new_ci_95_ub(pp) = ci_95_ub(cnt);
               new_ci_68_ub(pp) = ci_68_ub(cnt);
               cnt = cnt+1;
            end
        end
        rho = new_rho; ci_95_lb = new_ci_95_lb; ci_68_lb = new_ci_68_lb; 
        ci_95_ub = new_ci_95_ub; ci_68_ub = new_ci_68_ub; 
            
        if strcmp(paramsetting, 'bias')
            rho = abs(rho);
        end
        %polarscatter(theta, rho, colors(i)) 
        % hold on
        if length(theta) > 2
            % adding (1) to make full circle
            %polarplot([theta theta(1)], [rho rho(1)], colors(i));
            polarwitherrorbar([theta theta(1)], [rho rho(1)], ...
                [ci_95_lb ci_95_lb(1)], [ci_95_ub ci_95_ub(1)], set_min, colors(i));
        end
        thetaticks(possiblethetas_deg);
        rticks = get(gca,'rtick');
        rohlabels = arrayfun(@(x) sprintf('%.1f', x-set_min), rticks, 'un', 0);
        set(gca,'rticklabel',rohlabels)
        
        hold on
    end
    titlename = sprintf('%s Polar Plot: %s',subjname, paramsetting);
    title(titlename, 'FontSize', 14)
    
    f=get(gca,'Children');
    if numCond==4
        L1 = polarplot(nan, nan, 'color', colors(1));
        L2 = polarplot(nan, nan, 'color', colors(2));
        L3 = polarplot(nan, nan, 'color', colors(3));
        L4 = polarplot(nan, nan, 'color', colors(4));
        legend([L1, L2, L3,L4], condNames)
    elseif numCond==2
        L1 = polarplot(nan, nan, 'color', colors(1));
        L2 = polarplot(nan, nan, 'color', colors(2));
        legend([L1, L2], condNames)
    end
    
    saveas(gcf,sprintf('%s/pngs/%s_PP_%s_Alldata_%sconds.png',figuresdir,subjname, paramsetting,num2str(numCond)))
    saveas(gcf,sprintf('%s/figs/%s_PP_%s_Alldata_%sconds.fig',figuresdir,subjname, paramsetting,num2str(numCond)))
    saveas(gcf,sprintf('%s/bmps/%s_PP_%s_Alldata_%sconds.bmp',figuresdir,subjname, paramsetting,num2str(numCond)))
    
end